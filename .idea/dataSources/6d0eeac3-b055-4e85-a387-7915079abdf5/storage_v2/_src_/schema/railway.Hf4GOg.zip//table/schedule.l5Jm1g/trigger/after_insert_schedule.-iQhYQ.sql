create definer = root@`%` trigger after_insert_schedule
    after insert
    on schedule
    for each row
BEGIN
    DECLARE v_current_date DATE;
    DECLARE v_end_date DATE;
    DECLARE v_current_start_hour TIME;
    DECLARE v_current_end_hour TIME;
    DECLARE v_current_vet_document VARCHAR(10);
    DECLARE v_done INT DEFAULT 0;

    -- Cursor to select veterinarian documents randomly
    DECLARE vet_cursor CURSOR FOR 
        SELECT document 
        FROM veterinarian
        ORDER BY RAND();
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_done = 1;

    SET v_current_date = NEW.start_day;
    SET v_end_date = NEW.end_day;
    SET v_current_start_hour = NEW.start_hour;
    SET v_current_end_hour = NEW.end_hour;

    OPEN vet_cursor;

    date_loop: WHILE v_current_date <= v_end_date DO
        -- Fetch a random veterinarian document
        FETCH vet_cursor INTO v_current_vet_document;
        
        -- Reset cursor if we've gone through all vets
        IF v_done THEN
            CLOSE vet_cursor;
            OPEN vet_cursor;
            SET v_done = 0;
            FETCH vet_cursor INTO v_current_vet_document;
        END IF;

        WHILE v_current_start_hour < v_current_end_hour DO
            INSERT INTO available (
                schedule_id, 
                veterinarian_document, 
                day,  -- Changed from 'date' to 'day'
                start_hour, 
                end_hour, 
                status
            ) VALUES (
                NEW.schedule_id,
                v_current_vet_document,
                v_current_date,
                v_current_start_hour,
                ADDTIME(v_current_start_hour, '00:30:00'),
                'available'
            );

            SET v_current_start_hour = ADDTIME(v_current_start_hour, '00:30:00');
        END WHILE;

        SET v_current_start_hour = NEW.start_hour;
        SET v_current_date = DATE_ADD(v_current_date, INTERVAL 1 DAY);
    END WHILE date_loop;

    CLOSE vet_cursor;
END;

