create definer = root@`%` trigger update_status_after_delete
    after delete
    on appointment
    for each row
BEGIN
	UPDATE available
    SET status = 'available'
    WHERE available_id = OLD.available_id;
END;

