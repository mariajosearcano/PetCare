create definer = root@`%` trigger update_status_after_insert
    after insert
    on appointment
    for each row
BEGIN
	UPDATE available
    SET status = 'scheduled'
    WHERE available_id = NEW.available_id;
END;

