create definer = root@`%` trigger `check cancel date`
    before delete
    on appointment
    for each row
BEGIN
	IF DATEDIFF(OLD.day, CURDATE()) < 1 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Cancellation must be made at least 1 day before the appointment date';
    END IF;
END;

